﻿/* Angular module definition */
var app = angular.module("myApp", []);

/* Angular controller definition */
app.controller('currencyConverter', ['$scope', '$http', function ($scope, $http) {
    $scope.rates = {};
    /* Define fixer.io API call to get exchange rates */
    $http.get('http://api.fixer.io/latest?base=ZAR&symbols=USD,EUR,CAD')
            .then(function (res) {
                $scope.rates = res.data.rates;
                $scope.toType = $scope.rates.USD;
                $scope.fromType = $scope.rates.CAD;
                $scope.fromValue = 1;
                $scope.forExConvert();
            });
    $scope.forExConvert = function () {
        if ($scope.fromValue < 0)
            return $scope.toValue = '';
        else
            $scope.toValue = $scope.fromValue * ($scope.toType * (1 / $scope.fromType));
        $scope.toValue = $scope.toValue.toFixed(2);
    };
    $scope.$watch('toValue', function (newValue) {
        if (isNaN(newValue)) {
            $scope.toValue = '';
        }
    });
} ]);

/* Angular directive definition */
app.directive('allowOnlyNumbers', function () {
    return {
        require: '?ngModel',
        link: function ($scope, element, attrs, ngModelCtrl) {

            element.on('keydown', function (event) {
                var keyCode = []
                if (attrs.allowNegative == "true") {
                    keyCode = [8, 9, 36, 35, 37, 39, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 109, 110, 173, 190, 189];
                }
                else {
                    var keyCode = [8, 9, 36, 35, 37, 39, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 110, 173, 190];
                }

                if (attrs.allowDecimal == "false") {

                    var index = keyCode.indexOf(190);

                    if (index > -1) {
                        keyCode.splice(index, 1);
                    }

                }

                if ($.inArray(event.which, keyCode) == -1) event.preventDefault();
                else {
                    console.log(2);
                    var oVal = ngModelCtrl.$modelValue || '';
                    if ($.inArray(event.which, [109, 173]) > -1 && oVal.indexOf('-') > -1) event.preventDefault();
                    else if ($.inArray(event.which, [110, 190]) > -1 && oVal.indexOf('.') > -1) event.preventDefault();
                }
            })
            .on('blur', function () {

                if (element.val() == '' || parseFloat(element.val()) == 0.0 || element.val() == '-') {
                    ngModelCtrl.$setViewValue('1.00');
                }
                else if (attrs.allowDecimal == "false") {
                    ngModelCtrl.$setViewValue(element.val());
                }
                else {
                    if (attrs.fromValue) {
                        var fixedValue = parseFloat(element.val()).toFixed(attrs.fromValue);
                    }
                    else { var fixedValue = parseFloat(element.val()).toFixed(2); }
                    ngModelCtrl.$setViewValue(fixedValue);
                }

                ngModelCtrl.$render();
                $scope.$apply();
            });

            ngModelCtrl.$parsers.push(function (text) {
                var oVal = ngModelCtrl.$modelValue;
                var nVal = ngModelCtrl.$viewValue;
                console.log(nVal);
                if (parseFloat(nVal) != nVal) {

                    if (nVal === null || nVal === undefined || nVal == '' || nVal == '-') oVal = nVal;

                    ngModelCtrl.$setViewValue(oVal);
                    ngModelCtrl.$render();
                    return oVal;
                }
                else {
                    var decimalCheck = nVal.split('.');
                    if (!angular.isUndefined(decimalCheck[1])) {
                        if (attrs.fromValue)
                            decimalCheck[1] = decimalCheck[1].slice(0, attrs.fromValue);
                        else
                            decimalCheck[1] = decimalCheck[1].slice(0, 2);
                        nVal = decimalCheck[0] + '.' + decimalCheck[1];
                    }

                    ngModelCtrl.$setViewValue(nVal);
                    ngModelCtrl.$render();
                    return nVal;
                }
            });

            ngModelCtrl.$formatters.push(function (text) {
                if (text == '0' || text == null && attrs.allowDecimal == "false") return '0';
                else if (text == '0' || text == null && attrs.allowDecimal != "false" && attrs.fromValue == undefined) return '1.00';
                else if (text == '0' || text == null && attrs.allowDecimal != "false" && attrs.fromValue != undefined) return parseFloat(0).toFixed(attrs.fromValue);
                else if (attrs.allowDecimal != "false" && attrs.fromValue != undefined) return parseFloat(text).toFixed(attrs.fromValue);
                else return parseFloat(text).toFixed(2);
            });
        }
    };
});

