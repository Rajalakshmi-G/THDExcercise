﻿(function (ng) {

    "use strict";

    // Define AngularJS application module.
    window.currency = ng.module("Currency", []);

})(angular);