﻿(function (ng, app) {

    app.directive('currencycontrol', function () {
        return {
            scope: {
                currencyobject: '=',
                currencies: '=',
                direction: '=',
                source: '='
            },

            restrict: "E",

            templateUrl: "currencycontrol.html",

            controller: function ($scope) {
                $scope.changeDirection = function (source) {
                    if (source == 0) {
                        $scope.direction = 1;
                    }
                    else {
                        $scope.direction = 0;
                    }
                }
            }
        };
    });

})(angular, currency);